#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>

class Window : public QWidget
{
  Q_OBJECT

private:
  int func_id, func_id_2, k;
  const char *f_name, *f_name_2;
  double a, x_left, x_right;
  double b, y_up, y_down;
  int n, var, N;
  double (*f) (double);
  double (*df_f) (double);
  double *x = NULL, *y = NULL, *x2 = NULL;
  double *f_y = NULL, *f_x2 = NULL;
  double *c = NULL, *c2 = NULL, *d2 = NULL, m, *H = NULL; 
  double *yz = NULL, *ym1 = NULL, *ym2 = NULL, *xz = NULL, *n1 = NULL, *n2 = NULL;
  double zoom = 1;
  int flag;

public:
  ~Window();
 void rebutt(int k);
  void Input_08(void);
  void Calc_08(void);
  double f_08(double t);
  void Coeff_08(int n, int N, double *x, double *y, double *f_y, double *c);
  double Value_08(double t, double *c, double *x);
  double Quad(double x);
  void Input_30(void);
  void Calc_30(void);
  double f_30(double t);
  void Coeff_30(int n, double *x2, double *f_x2, double *c2);
  double Value_30(double t, double *c2, double *x2);
  double Mid(int N, int i, double *x, double *y, double *f_y);
  double f_method1(double x);
  double f_method2(double x);


  Window (QWidget *parent);
  QSize minimumSizeHint () const;
  QSize sizeHint () const;

  int parse_command_line (int argc, char *argv[]);
  void CalcMaxAndMin(double (*f)(double x), double* max_y, double* min_y);

public slots:
  void change_func ();
  void change_graphs ();
  void zoom_in();
  void zoom_out();
  void increase_n();
  void reduce_n();
  void plus();
  void minus();

protected:

void paintEvent (QPaintEvent *event);
};

#endif
