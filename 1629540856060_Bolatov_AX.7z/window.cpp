#include <QPainter>
#include <stdio.h>
#include <math.h>
#include "window.h"
#include <stdlib.h>
#include <limits>
#include <cfloat>
#define DEFAULT_A -10
#define DEFAULT_B 10
#define DEFAULT_N 10
#define DEFAULT_NN 20
#define DEFAULT_K 0
static double f_0 (double x) {return 1 + 0 * x;}
static double f_1 (double x) {return x;}
static double f_2 (double x) {return x * x;}
static double f_3 (double x) {return x * x * x;}
static double f_4 (double x) {return x * x * x * x;}
static double f_5 (double x) {return exp(x);}
static double f_6 (double x) {return 1 / (25 * x * x + 1);}
static double df_0 (double x) {return 0 + 0 * x;}
static double df_1 (double x) {return 1 + 0 * x;}
static double df_2 (double x) {return 2 * x;}
static double df_3 (double x) {return 3 * x * x;}
static double df_4 (double x) {return 4 * x * x * x;}
static double df_5 (double x) {return exp(x);}
static double df_6 (double x) {return -50 * (x / ((25 * x * x + 1) * (25 * x * x + 1)));}
double Window::f_method1(double x) {return f_08(x);}
double Window::f_method2(double x) {return f_30(x);}

Window::Window (QWidget *parent)
  : QWidget (parent)
{
  a = DEFAULT_A;
  b = DEFAULT_B;
  n = DEFAULT_N;
  N = DEFAULT_NN;
  func_id = 0;
  change_func();
  func_id_2 = 0;
  m = 0;
  zoom = 1;
  flag = 0;
  change_graphs();
  zoom_in();
  zoom_out();
  increase_n();
  reduce_n();
  plus();
  minus();
}
void Window:: rebutt(int k)
{
	func_id = k;
	func_id--;
	N = n + n;
	change_func();
}
Window::~Window () {
}
QSize Window::minimumSizeHint () const {return QSize (100, 100);}
QSize Window::sizeHint () const {return QSize (1000, 1000);}
int Window::parse_command_line (int argc, char *argv[])
{
	if((argc > 1 && argc < 5) || argc > 5)
		return -1;

  if (argc == 5 && (sscanf (argv[1], "%lf", &a) != 1
      || sscanf (argv[2], "%lf", &b) != 1
      || b - a < 1.e-6
      ||  sscanf (argv[3], "%d", &n) != 1
      ||  sscanf(argv[4], "%d", &k)!= 1
      || n <= 2
      || k > 6
      || k < 0))
    return -2;
  if(argc == 5)
	  rebutt(k);
  return 0;
}
void Window::change_func ()
{
  func_id = (func_id + 1) % 7;
  switch (func_id)
    {
      case 0:
        f_name = "f (x) = 1";
        f = f_0;
	df_f = df_0;
        break;
      case 1:
        f_name = "f (x) = x";
        f = f_1;
	df_f = df_1;
        break;
      case 2:
        f_name = "f (x) = x * x";
        f = f_2;
	df_f = df_2;
        break;
      case 3:
        f_name = "f (x) = x * x * x";
        f = f_3;
	df_f = df_3;
        break;
      case 4:
        f_name = "f (x) = x * x * x * x";
        f = f_4;
	df_f = df_4;
        break;
      case 5:
        f_name = "f (x) = EXP(x)";
        f = f_5;
	df_f = df_5;
        break;
      case 6:
        f_name = "f (x) = 1 / (25 * x * x + 1)";
        f = f_6;
	df_f = df_6;
        break;
    }
 	update ();
}

void Window::change_graphs()
{
	func_id_2 = (func_id_2 + 1) % 4;
	switch (func_id_2)
	{
	case 0:
		f_name_2 = "8 method";
		var = func_id_2;
		break;
	case 1:
		f_name_2 = "30 method";
		var = func_id_2;
		break;
	case 2:
		f_name_2 = "two methods";
		var = func_id_2;
		break;
	case 3:
		f_name_2 = "oshibka/pogreshnoct'";
		var = func_id_2;
		break;

	}
	update ();
}
void Window::Input_08(void)
{
	int i, j = N / 2;
	double h;
	h = (b - a)/(N - 1);
	for (i = 0; i < N; i++){
		y[i] = a + i * h;
		f_y[i] = f(y[i]);	
	}
	f_y[j] += 0.1 * flag * m;
	h = (b - a)/(n - 1);
	for (i = 0; i < n; i++) x[i] = a + i * h;
}
void Window::Calc_08(void)
{
	x = (double*)malloc(n * sizeof(double));
	y = (double*)malloc(N * sizeof(double));
	f_y = (double*)malloc(N * sizeof(double));
	Input_08();
	Coeff_08(n, N, x, y, f_y, c);	
	if (y) free(y);
	if (f_y) free(f_y);	    
}
double Window::f_08(double t)
{
	return Value_08(t, c, x);
}
void Window::Coeff_08(int n, int N, double *x, double *y, double *f_y, double *c)
{
	int i, p = 0;
	double hf, h = (b - a)/(n - 1), hh = h / 3.0, hhh = hh / 2.0, r;
	H = (double*)malloc(4*n * sizeof(double));			
	H[0] = hh;
	H[n - 1] = hh;
	H[n] = 0.5;
	H[3 * n - 2] = hhh;
	h = (b - a)/(N - 1);
	while (p < N && y[p+1] < x[1]) p++;
	if (p == N) p = 0;
	hf = f_y[p+1] - f_y[p];
	r = -1 * (hf / h * (x[1] - y[p + 1]) + f_y[p + 1]) * f_2(x[1]) / 2.0 - f_y[0] * x[0] * (x[0] / 2.0 - x[1]);
	for (i = 0; i < p; i++)
		r += (f_y[i + 1] - f_y[i]) / h * (f_2(y[i]) * (y[i] / 3.0 - x[1]) - f_2(y[i+1]) * (y[i + 1] / 3.0 - x[1])) / 2.0;
	r = (r + hf / h * (2.0 * f_3(x[1]) / 3.0 + f_2(y[p]) * (y[p] / 3.0 - x[1])) / 2.0) / (x[0] - x[1]);
	H[3 * n] = r;
	for (i = 1; i < n - 1; i++){
		H[i] = hh * 2;
		H[n + i] = hhh;
		H[2 * n + i - 1] = hhh;
		H[3 * n + i] = Mid(N, i, x, y, f_y);
	}
	p = N-2;
	while (p >= 0 && y[p] > x[n-2]) p--;
	if (p < 0) p = N;
	hf = f_y[p+1] - f_y[p];
	r = x[n - 1] * (x[n - 1]/2.0 - x[n - 2]) * f_y[N - 1];
	r += (hf / h * (x[n - 2] - y[p + 1]) + f_y[p + 1]) * x[n - 2] * x[n - 2] / 2.0;
	r += hf / h * (y[p + 1] * y[p + 1] * (x[n - 2] - y[p + 1] / 3.0) - 2.0 * x[n - 2] * x[n - 2] * x[n - 2] / 3.0) / 2.0;
	for (i = p + 1; i < N - 1; i++)
		r += (f_y[i + 1] - f_y[i]) / h * (f_2(y[i]) * (y[i]/3.0 - x[n - 2]) - f_2(y[i + 1]) * (y[i + 1] / 3.0 - x[n - 2])) / 2.0;
	r /= (x[n - 1] - x[n - 2]);
	H[4 * n - 1] = r;
	for (i = 1; i < n-1; i++){
		H[i] -= H[2 * n + i - 1] * H[n + i - 1];
		H[n + i] /= H[i];
	}
	H[n - 1] -= H[3 * n - 2] * H[2 * n - 2];
	c[0] = H[3 * n] / H[0];
	for (i = 1; i < n; i++)
		c[i] = (H[3 * n + i] - H[2 * n + i - 1] * c[i - 1]) / H[i];
	for (i = n - 2; i >= 0; i--)
		c[i] -= H[n + i] * c[i + 1];
	if (H) free(H);
}
double Window::Value_08(double t, double *c, double *x)
{
	int i;

	if (t < x[1]) return c[0] * (t - x[1])/(x[0] - x[1]) + c[1] * (t - x[0])/(x[1] - x[0]);

	for (i = 1; i < n - 2; i++)
		if (t <= x[i + 1]) return c[i] * (t - x[i + 1])/(x[i] - x[i + 1]) + c[i + 1] * (t - x[i])/(x[i + 1] - x[i]);

	return c[n - 2] * (t - x[n - 1])/(x[n - 2] - x[n - 1]) + c[n - 1] * (t - x[n - 2])/(x[n - 1] - x[n - 2]);
}
double Window::Mid(int N, int i, double *x, double *y, double *f_y)
{
	int j, k, p, q;
	double r1 = 0, r2 = 0;
	double h = (b - a) / (N - 1), hh1, hh2, hh3, hh = (b-a) / (n-1);
	if (i > 3)	
		k = 2*i-3;
	else
		k = 0;
	while (k < N && y[k] <= x[i - 1]) k++;
	if (k == N) k = 0;
	else k--;
	
	p = k;
	while (p < N && y[p] <= x[i]) p++;
	if (p == N) p = 0;
	else p--; 	

	q = p;
	while (q < N && y[q] < x[i + 1]) q++;
	if (q == N) q = N-2;
	else q--;
	hh1 = f_y[p+1] - f_y[p];
	hh2 = f_y[k+1] - f_y[k];
	hh3 = f_y[q+1] - f_y[q];
	r1 = (hh1 / h * (x[i] - y[p + 1]) + f_y[p + 1]) * x[i] * (x[i]/2.0 - x[i - 1]);
	r1 += f_2(x[i - 1]) * (hh2 / h * (x[i - 1] - y[k + 1]) + f_y[k + 1])/2.0;
	r1 -= hh2 / h * (f_2(y[k + 1]) * (y[k + 1]/3.0 - x[i - 1]) + 2.0 * f_3(x[i - 1]) / 3.0)/2.0;
	for (j = k + 1; j < p; j++)
	r1 += (f_y[j + 1] - f_y[j]) / h * (f_2(y[j]) * (y[j]/3.0 - x[i - 1]) - f_2(y[j + 1]) * (y[j + 1]/3.0 - x[i - 1]))/2.0;
	r1 += hh1 / h * (f_2(y[p]) * (y[p]/3.0 - x[i - 1]) - f_2(x[i]) * (x[i]/3.0 - x[i - 1]))/2.0;
	r1 /= hh;
	r2 = (hh3 / h * (x[i + 1] - y[q + 1]) + f_y[q + 1]) * (-1) * f_2(x[i + 1]) / 2.0;
	r2 -= (hh1 / h * (x[i] - y[p + 1]) + f_y[p + 1]) * x[i] * (x[i]/2.0 - x[i + 1]);
	r2 += hh1 / h * (f_2(x[i]) * (x[i]/3.0 - x[i + 1]) - f_2(y[p + 1]) * (y[p + 1] / 3.0 - x[i + 1]))/2.0;
	for (j = p + 1; j < q; j++)
	r2 += (f_y[j + 1] - f_y[j]) / h * (f_2(y[j]) * (y[j] / 3.0 - x[i + 1]) - f_2(y[j + 1]) * (y[j + 1]/3.0 - x[i + 1]))/2.0;
	r2 += hh3 / h * (2.0 * f_3(x[i + 1]) / 3.0 + f_2(y[q]) * (y[q]/3.0 - x[i + 1]))/2.0;
	r2 /= -hh;
	return r1 + r2;
}
void Window::Input_30(void)
{
	int i;
	double h;
	int j = n / 2;
	h = (b - a)/(n - 1);
	for (i = 0; i < n; i++){
		x2[i] = a + i * h;
		f_x2[i] = f(x2[i]);
	}
	f_x2[j] += 0.1 * flag * m;
}
void Window::Calc_30(void)
{
	x2 = (double*)malloc(n * sizeof(double));
	f_x2 = (double*)malloc(n * sizeof(double));
	Input_30();
	Coeff_30(n, x2, f_x2, c2);
	if (f_x2) free(f_x2);
}

double Window::f_30(double t)
{
	return Value_30(t, c2, x2);
}
double Window::Quad(double x) {return (f(x + 2 * 1e-8) - 2 * f(x) + f (x - 2 * 1e-8))/ f_2(1e-8) / 4;}
void Window::Coeff_30(int n, double *x2, double *f_x2, double *c2)
{
	int i, j;
	double t1, t2, h, hh;
	d2 = (double*)malloc(n * sizeof(double));
	h = x2[1] - x2[0];
	hh = x2[n-1] - x2[n-2];
	for (i = 1; i < n - 1; i++){
		t1 = (f_x2[i] - f_x2[i - 1]) / h;
		t2 = (f_x2[i + 1] - f_x2[i]) / h;
		if (t1 * t2 > 0){ 
			if (t1 > 0)
				d2[i] =  1; 
			else
				d2[i] = -1;
			if (fabs(t1) > fabs(t2)) 
				d2[i] *= fabs(t2);
			else
				d2[i] *= fabs(t1);
		}
		else d2[i] = 0.0;
	}
	t1 = (f_x2[1] - f_x2[0]) / h;
	t2 = (f_x2[n - 1] - f_x2[n - 2]) / hh;
	d2[0] = 1.5 * t1 - d2[1] / 2.0 - Quad(x2[0]) * h / 4;
	d2[n - 1] = 1.5 * t2 - d2[n - 2] / 2.0 + Quad(x2[n - 1]) * h / 4;
	j = 0;
	for (i = 0; i < n - 1; i++, j += 4){
		c2[j + 0] = f_x2[i];
		c2[j + 1] = d2[i];
		if (i < n-2){
			t1 = (f_x2[i + 1] - f_x2[i]) / h;
			c2[j + 2] = (3 * t1 - 2 * d2[i] - d2[i + 1]) / h;
			c2[j + 3] = (d2[i] + d2[i + 1] - 2 * t1) / f_2(h);
		}		
		else{
			t1 = (f_x2[i + 1] - f_x2[i]) / hh;				
			c2[j + 2] = (3 * t1 - 2 * d2[i] - d2[i + 1]) / hh;
			c2[j + 3] = (d2[i] + d2[i + 1] - 2 * t1) / f_2(hh);
		}		
	}
	if (d2) free(d2);
}
double Window::Value_30(double t, double *c2, double *x2)
{
	int i;
	for (i = 0; i < n - 2; i++) 
		if (t <= x2[i + 1]) 
			break;
	return c2[4 * i] + c2[4 * i + 1] * (t - x2[i]) +
		c2[4 * i + 2] * (t - x2[i]) * (t - x2[i]) +
		c2[4 * i + 3] * (t - x2[i]) * (t - x2[i]) * (t - x2[i]);
}
void Window::CalcMaxAndMin(double (*f)(double x), double* max_y, double* min_y)
{
	double delta_y, delta_x = (b - a) / (width() - 1);
	double y1, x1;
	*max_y = *min_y = 0;
 	for (x1 = a; x1 - b < 1.e-6; x1 += delta_x){
     		y1 = f (x1);
    	 	if (y1 < *min_y)
      	 		*min_y = y1;
    		if (y1 > *max_y)
       			*max_y = y1;
  	}
	m = fabs(*max_y);
	if(m < fabs(*min_y))
		m = fabs(*min_y);
	printf("max игрик = %lf !\n", m);
 	delta_y = 0.01 * (*max_y - *min_y);
	*min_y -= delta_y;
 	*max_y += delta_y;
}
void Window::zoom_in()
{
	a /= 2;
	b /= 2;
	zoom *= 2;
	update();
}
void Window::zoom_out()
{
	if (b > 150 && func_id == 5){//exp почему то аварийно выпадала когада увеличивал с 160 на 320 размерность, решил добавить условие
		printf("Ошибка! Превышение!\n");
		update();
	}
	else{
		a *= 2;
		b *= 2;
		zoom /= 2;
		update();
	}
}
void Window::increase_n()
{
	n *= 2;
	N *= 2;
	update();
}
void Window::reduce_n()
{
	if(n != 2 && n != 3){
		n /= 2;
		N /= 2;
		update();
	}
}
void Window::plus()
{
	flag++;
	update();
}
void Window::minus()
{
	flag--;
	update();
}
void Window::paintEvent (QPaintEvent * /* event */)
{  
  	QPainter painter (this);
  	double /*delta_x = (b - a) / (n - 1);*/delta_x = (b - a) /(width());
  	//if(n > width())
		//delta_x = (b - a) / (n - 1);
	double maxy, miny;
	double h, y11, y12, x11, r1 = 0, r2 = 0;
	int i, nn = 2, nnn = 2;
	double *yzz;
	h = (b - a) / width();	   		
	for (x11 = a + delta_x; x11 - b < 1.e-6; x11 += delta_x) nn++;
	for (x11 = a + h; x11 - b < 1.e-6; x11 += h) nnn++;
	xz = NULL;
	yz = NULL;
	ym1 = NULL;
	ym2 = NULL;
	n2 = NULL;
	n1 = NULL;
	yz = (double*)malloc(nn * sizeof(double));   		   		
	yzz = (double*)malloc(nnn * sizeof(double));   		   		
	xz = (double*)malloc(nn * sizeof(double));	
	x11 = a;
  	for (i = 0; i < nnn - 1; i++){				
		yzz[i] = f(x11);     		  	
		x11 += h;			
	}
	yzz[nnn-1] = f(b);	
	if (var == 0){	
		c = (double*)malloc(n * sizeof(double)); 
		//printf("okey1\n");
		Calc_08();
		//printf("okey1\n");
		ym1 = (double*)malloc(nn * sizeof(double));
		n1 = (double*)malloc(nn * sizeof(double));
		xz[0] = a;
  		for (i = 0; i < nn - 1; i++){	
			ym1[i] = f_method1(xz[i]);			
			yz[i] = f(xz[i]);     		  	
			xz[i+1] = xz[i] + delta_x;
			n1[i] = fabs(yz[i] - ym1[i]);			
		}
		//printf("okey1\n");
		xz[nn-1] = b;
		ym1[nn-1] = f_method1(xz[nn-1]);
  		yz[nn-1] = f(xz[nn-1]);
		n1[nn-1] = fabs(yz[nn-1] - ym1[nn-1]);
	}	
	else if (var == 1){
		c2 = (double*)malloc(4 * (n - 1) * sizeof(double));
		ym2 = (double*)malloc(nn * sizeof(double));   		
		n2 = (double*)malloc(nn * sizeof(double));
		Calc_30();
		//printf("okey\n");
		xz[0] = a;
  		for (i = 0; i < nn - 1; i++){	
			ym2[i] = f_method2(xz[i]);			
			yz[i] = f(xz[i]);     		  	
			xz[i+1] = xz[i] + delta_x;			
			n2[i] = fabs(yz[i] - ym2[i]);			
		}
		//printf("okey\n");
		xz[nn-1] = b;
		ym2[nn-1] = f_method2(xz[nn-1]);
  		yz[nn-1] = f(xz[nn-1]);
		n2[nn-1] = fabs(yz[nn-1] - ym2[nn-1]);	
	}	
	else{
		c = (double*)malloc(n * sizeof(double)); 
		c2 = (double*)malloc(4 * (n - 1) * sizeof(double));
		ym1 = (double*)malloc(nn * sizeof(double));   		
		ym2 = (double*)malloc(nn * sizeof(double));   		
		n1 = (double*)malloc(nn * sizeof(double));
		n2 = (double*)malloc(nn * sizeof(double));
		//printf("okey2\n");
		Calc_08();
		//printf("okey2\n");
		Calc_30();
		//printf("okey2\n");
		xz[0] = a;
  		for (i = 0; i < nn - 1; i++){	
			ym1[i] = f_method1(xz[i]);
			ym2[i] = f_method2(xz[i]);			
			yz[i] = f(xz[i]);     		  	
			n1[i] = fabs(yz[i] - ym1[i]);			
			n2[i] = fabs(yz[i] - ym2[i]);			
			xz[i+1] = xz[i] + delta_x;		
		}
		xz[nn-1] = b;
		ym1[nn-1] = f_method1(xz[nn-1]);
  		ym2[nn-1] = f_method2(xz[nn-1]);
  		yz[nn-1] = f(xz[nn-1]);
		n1[nn-1] = fabs(yz[nn-1] - ym1[nn-1]);
		n2[nn-1] = fabs(yz[nn-1] - ym2[nn-1]);	
	}	
	x_right = a;
	x_left = b;
	CalcMaxAndMin(f, &maxy, &miny);
  	painter.save ();
  	painter.translate (0.5 * width(), 0.5 * height());
  	painter.scale ((width() / (b - a)), ((-height() / (maxy - miny))));
  	painter.translate (-0.5 * (a + b), -0.5 * (miny + maxy));
  	QPen pen("green");
  	pen.setWidth(0);
  	painter.setPen (pen);
	double x1, y1, y2;  	
	if(var == 0 || var == 2){
  		x1 = xz[0];
		y1 = ym1[0];
  		for (i = 1; i < nn; i++){	
			x11 = xz[i];     			
			y2 = ym1[i];
     		  	painter.drawLine (QPointF (x1, y1), QPointF (x11, y2));
		  	x1 = x11, y1 = y2;
        	}
  	}	
	pen.setColor("blue");
	pen.setWidth(0);
	painter.setPen (pen);
  	if(var == 1 || var == 2){
  		x1 = xz[0];
		y1 = ym2[0];
  		for (i = 1; i < nn; i++){	
			x11 = xz[i];     			
			y2 = ym2[i];
     		  	painter.drawLine (QPointF (x1, y1), QPointF (x11, y2));
		  	x1 = x11, y1 = y2;
        	}
  	}
  	pen.setColor("black");
  	pen.setWidth(0);
  	painter.setPen (pen);
  	if(var != 3){
	  	double xx = a + n / 2 * (b - a) / (n - 1);
		x1 = a;
		y1 = yzz[0];
  		for (i = 1; i < nnn; i++){	
			x11 = x1 + h;     			
			y2 = yzz[i];
			if(fabs(x11 - xx) < 1.e-6){
		  		y2 += 0.1 * flag * m;
	  		}     		  	
			painter.drawLine (QPointF (x1, y1), QPointF (x11, y2));
		  	x1 = x11, y1 = y2;
        	}
  	}
  	pen.setColor("green");
  	pen.setWidth(0);
  	painter.setPen (pen);
	if(var == 3){
  		x1 = xz[0];
		y1 = n1[0];
  		for (i = 1; i < nn; i++){
			x11 = xz[i];	  		
			y2 = n1[i];
     	  		painter.drawLine (QPointF (x1, y1), QPointF (x11, y2));
	  		x1 = x11, y1 = y2;
        	}
 		pen.setColor("blue");
        	pen.setWidth(0);
        	painter.setPen (pen);
  		x1 = xz[0];
		y1 = n2[0];
  		for (i = 1; i < nn; i++){
			x11 = xz[i];	  		
			y2 = n2[i];
     	  		painter.drawLine (QPointF (x1, y1), QPointF (x11, y2));
	  		x1 = x11, y1 = y2;
        	}
	}
	if (var > 1){	
		for (i = 0; i < nn; i++){
		    	 y11 = n1[i];
		   	 if (y11 > r1)
		       		r1 = y11;
		     	 y12 = n2[i];
		    	 if (y12 > r2)
		       		r2 = y12;
		}
	}
	else if (var == 1){
		for (i = 0; i < nn; i++){
		    	 y11 = n2[i];
		   	 if (y11 > r2)
		       		r2 = y11;
		}
	}
	else{
		for (i = 0; i < nn; i++){
		    	 y11 = n1[i];
		   	 if (y11 > r1)
		       		r1 = y11;
		}
	}
  	pen.setWidth(0);
  	pen.setColor("black");
  	painter.setPen (pen);
  	painter.drawLine (a, 0, b, 0);
  	painter.drawLine (0, maxy, 0, miny);
	painter.restore ();
  	char k[128];
	painter.setPen ("black");
 	painter.drawRect(0, 0, 220, 180); 
  	painter.drawText (45, 20, f_name);
  	sprintf(k, "k = %d", func_id);
  	painter.drawText(5, 20, k);
  	painter.drawText (5, 40, f_name_2);
  	if(var != 3){
 		sprintf(k, "max = %lf", m);
 	 	painter.drawText (5, 120, k);
  	}
  	sprintf(k, "отрезок [a,b] = [%.2lf,", a);
  	painter.drawText (5, 60, k);
  	sprintf(k, "%.2lf]", b);
  	painter.drawText (160, 60, k);
  	sprintf(k, "n = %d", n);
  	painter.drawText (5, 80, k);
  	sprintf(k, "p = %d", flag);
  	painter.drawText (5, 100, k);
  	if(var != 1){
		painter.setPen("blue");
		sprintf(k, "ошибка 8-го = %e", r1);
	  	painter.drawText (5, 150, k);
  	}
  	if(var != 0){
		painter.setPen("blue");
	 	sprintf(k, "ошибка 30-го = %e", r2);
	 	painter.drawText (5, 170, k);
  	}
	if (var > 1){
		free (c);
		free(c2);
		free (xz);
		free(yz);
		free(ym1);
		free(ym2);
		free(n1);
		free(n2);
		free(x2);	
		free(x);		
	}
	else if (var == 1){
		free(c2);
		free (xz);
		free(yz);
		free(ym2);
		free(n2);
		free(x2);		
	}
	else {
		free (c);
		free (xz);
		free(yz);
		free(ym1);
		free(n1);
		free(x);		
	}
}
